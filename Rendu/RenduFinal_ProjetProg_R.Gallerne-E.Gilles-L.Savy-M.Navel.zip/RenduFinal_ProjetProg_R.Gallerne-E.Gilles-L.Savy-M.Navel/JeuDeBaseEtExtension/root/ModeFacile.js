function LancementFacile(){
    
} 